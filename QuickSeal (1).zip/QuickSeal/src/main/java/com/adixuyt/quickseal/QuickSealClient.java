package com.adixuyt.quickseal;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.Block;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

// Mod napisany od zera (bez dostępu do oryginalnego kodu źródłowego "Error Killer"),
// odtwarzający opisane działanie + dwie zmiany na życzenie: obsługa off-handu i keybindy.
public class QuickSealClient implements ClientModInitializer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path configPath;
    private static final Config CONFIG = new Config();

    private static KeyBinding KEY_TOGGLE, KEY_COBWEB, KEY_OBSIDIAN;

    // Zaplanowana akcja czeka "delay" ticków, potem się wykonuje.
    private static int pendingTicks = -1;
    private static BlockHitResult pendingHit;
    private static boolean pendingIsCobweb;

    @Override
    public void onInitializeClient() {
        configPath = MinecraftClient.getInstance().runDirectory.toPath().resolve("config/quickseal.json");
        loadConfig();

        KEY_TOGGLE = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.quickseal.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "key.category.quickseal"));
        KEY_COBWEB = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.quickseal.cobweb", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "key.category.quickseal"));
        KEY_OBSIDIAN = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.quickseal.obsidian", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "key.category.quickseal"));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient client) {
        while (KEY_TOGGLE.wasPressed()) {
            CONFIG.enabled = !CONFIG.enabled;
            saveConfig();
            if (client.player != null) {
                client.player.sendMessage(Text.literal("§7[§bQuick Seal§7] " + (CONFIG.enabled ? "§aWłączony" : "§cWyłączony")), true);
            }
        }

        if (CONFIG.enabled) {
            while (KEY_COBWEB.wasPressed()) tryArm(client, true);
            while (KEY_OBSIDIAN.wasPressed()) tryArm(client, false);
        }

        if (pendingTicks >= 0) {
            pendingTicks--;
            if (pendingTicks <= 0) {
                execute(client);
                pendingTicks = -1;
                pendingHit = null;
            }
        }
    }

    /** Zapamiętuje cel (dźwignia/przycisk) i odlicza skonfigurowane opóźnienie przed wykonaniem. */
    private void tryArm(MinecraftClient client, boolean cobweb) {
        if (client.player == null || client.world == null) return;
        if (!(client.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        Block target = client.world.getBlockState(hit.getBlockPos()).getBlock();
        if (!(target instanceof LeverBlock) && !(target instanceof ButtonBlock)) return;

        pendingHit = hit;
        pendingIsCobweb = cobweb;
        int delayTicks = Math.max(0, (cobweb ? CONFIG.cobwebDelayMs : CONFIG.obsidianDelayMs) / 50);
        pendingTicks = delayTicks;
        if (delayTicks == 0) { execute(client); pendingTicks = -1; pendingHit = null; }
    }

    private void execute(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null || pendingHit == null) return;
        var player = client.player;

        // Ten sam blok wciąż tam jest? (mogło się zmienić w czasie odliczania).
        Block target = client.world.getBlockState(pendingHit.getBlockPos()).getBlock();
        if (!(target instanceof LeverBlock) && !(target instanceof ButtonBlock)) return;

        Item wanted = pendingIsCobweb ? Items.COBWEB : Items.OBSIDIAN;
        if (!wantedMatches(player.getOffHandStack(), wanted)) {
            // Off-hand: nic nie trzeba przełączać, przedmiot jest już aktywny w tej ręce.
            if (wantedMatches(player.getMainHandStack(), wanted)) {
                client.interactionManager.interactBlock(player, Hand.MAIN_HAND, pendingHit);
                return;
            }
            int slot = findInHotbar(player, wanted);
            if (slot < 0) {
                player.sendMessage(Text.literal("§7[§bQuick Seal§7] §cBrak " + (pendingIsCobweb ? "pajęczyny" : "obsydianu") + " w ekwipunku."), true);
                return;
            }
            int original = player.getInventory().getSelectedSlot();
            setSelectedSlot(client, slot);
            client.interactionManager.interactBlock(player, Hand.MAIN_HAND, pendingHit);
            setSelectedSlot(client, original);
        } else {
            client.interactionManager.interactBlock(player, Hand.OFF_HAND, pendingHit);
        }
    }

    private static boolean wantedMatches(ItemStack stack, Item wanted) {
        return !stack.isEmpty() && stack.getItem() == wanted;
    }

    private static int findInHotbar(net.minecraft.entity.player.PlayerEntity player, Item wanted) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).getItem() == wanted) return i;
        }
        return -1;
    }

    private static void setSelectedSlot(MinecraftClient client, int slot) {
        client.player.getInventory().setSelectedSlot(slot);
        client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private static void saveConfig() {
        if (configPath == null) return;
        try {
            Files.createDirectories(configPath.getParent());
            JsonObject o = new JsonObject();
            o.addProperty("enabled", CONFIG.enabled);
            o.addProperty("cobwebDelayMs", CONFIG.cobwebDelayMs);
            o.addProperty("obsidianDelayMs", CONFIG.obsidianDelayMs);
            Files.writeString(configPath, GSON.toJson(o));
        } catch (IOException ignored) {}
    }

    private static void loadConfig() {
        try {
            if (!Files.exists(configPath)) return;
            JsonObject o = JsonParser.parseString(Files.readString(configPath)).getAsJsonObject();
            if (o.has("enabled")) CONFIG.enabled = o.get("enabled").getAsBoolean();
            if (o.has("cobwebDelayMs")) CONFIG.cobwebDelayMs = o.get("cobwebDelayMs").getAsInt();
            if (o.has("obsidianDelayMs")) CONFIG.obsidianDelayMs = o.get("obsidianDelayMs").getAsInt();
        } catch (Exception ignored) {}
    }

    private static class Config {
        boolean enabled = true;
        int cobwebDelayMs = 0;
        int obsidianDelayMs = 0;
    }
}
