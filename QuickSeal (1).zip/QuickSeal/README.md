# Quick Seal — Fabric 1.21.4

Autor / branding: **Adixu_YT**

Napisane od zera na podstawie opisu działania moda "Error Killer" (bez dostępu do jego kodu źródłowego).

## Funkcje

- Szybkie stawianie **pajęczyny** lub **obsydianu**, gdy patrzysz na dźwignię lub przycisk.
- Działa niezależnie od tego, czy przedmiot trzymasz w **głównej ręce**, czy w **off-handzie** (off-hand nie wymaga przełączania slotu — jest już aktywny).
- Jeśli przedmiotu nie ma w off-handzie, mod sam znajdzie go na hotbarze, przełączy slot, postawi blok i wróci na oryginalny slot.
- Trzy w pełni konfigurowalne klawisze w **Opcje → Sterowanie → Quick Seal**:
  - **Włącz/wyłącz moda**
  - **Szybko postaw pajęczynę**
  - **Szybko postaw obsydian**
  Domyślnie żaden klawisz nie jest przypisany — ustaw je sam w Sterowaniu.
- Opóźnienie (w milisekundach) przed postawieniem bloku, osobno dla pajęczyny i osobno dla obsydianu — do zmiany w `config/quickseal.json` (pole `cobwebDelayMs` / `obsidianDelayMs`).

## Budowanie

Wymaga JDK 21 i Gradle/Gradle Wrapper. W katalogu projektu uruchom:

    gradle build

Gotowy plik JAR znajdzie się w `build/libs/`.
